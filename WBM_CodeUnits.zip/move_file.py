#!/usr/bin/env python
# coding: utf-8

# In[1]:


# This script moves files from LFS to HDFS


# In[3]:


# !pip install ConfigParser


# In[95]:


# Import dependencies
# In Python 3 ConfigParser has been renamed to configparser
import configparser
import glob
import os
import csv


# In[16]:


# Setting environment variables
env = input("Enter environment :: ")


# In[171]:


# Create ConfigParser object
config = configparser.ConfigParser()

# Read from param file
config.read('wbm_params.prm')

# Fetch required details
print(config.get('OVIA','CLINICAL_HDFS_PATH'))


# In[142]:


# Making environment related modifications
# DEV changes
# Make similar changes for each source
if env.lower() == 'dev':
        
    # LIVONGO related DEV changes
    liv_local_path = config.get('LIVONGO','LOCAL_PATH').replace('{$edge_env}','dev')
    liv_wkly_enrol_hdfs_path = config.get('LIVONGO','WEEKLY_ENROL_HDFS_PATH').replace('{$hdfs_env}','dev')
    liv_wkly_bp_hdfs_path = config.get('LIVONGO','WEEKLY_BP_HDFS_PATH').replace('{$hdfs_env}','dev')
    liv_wkly_bg_hdfs_path = config.get('LIVONGO','WEEKLY_BG_HDFS_PATH').replace('{$hdfs_env}','dev')
    
    # OMADA related DEV changes
    omada_local_path = config.get('OMADA','LOCAL_PATH').replace('{$edge_env}','dev')
    omada_enroll_hdfs_path = config.get('OMADA','ENROLD_MEM_HDFS_PATH').replace('{$hdfs_env}','dev')
    omada_clinical_hdfs_path = config.get('OMADA','CLINICAL_HDFS_PATH').replace('{$hdfs_env}','dev')
    omada_nclinical_hdfs_path = config.get('OMADA','NCLINICAL_HDFS_PATH').replace('{$hdfs_env}','dev')
    
    # HINGE HEALTH related DEV changes
    hinge_local_path = config.get('HINGEHEALTH','LOCAL_PATH').replace('{$edge_env}','dev')
    hinge_enroll_hdfs_path = config.get('HINGEHEALTH','ENROLL_HDFS_PATH').replace('{$hdfs_env}','dev')
    hinge_clinical_hdfs_path = config.get('HINGEHEALTH','ENG_HDFS_PATH').replace('{$hdfs_env}','dev')
    
    # OVIA related DEV changes
    ovia_local_path = config.get('OVIA','LOCAL_PATH').replace('{$edge_env}','dev')
    ovia_clinical_hdfs_path = config.get('OVIA','CLINICAL_HDFS_PATH').replace('{$hdfs_env}','dev')
    ovia_enroll_hdfs_path = config.get('OVIA','ENROLL_HDFS_PATH').replace('{$hdfs_env}','dev')
    
    # TIVITY related DEV changes
    tvty_local_path = config.get('TIVITY','LOCAL_PATH').replace('{$edge_env}','dev')
    tvty_hdfs_path = config.get('TIVITY','HDFS_PATH').replace('{$hdfs_env}','dev')

# TEST changes
elif env.lower() == 'test':
        
    # LIVONGO related TEST changes
    liv_local_path = config.get('LIVONGO','LOCAL_PATH').replace('{$edge_env}','tst')
    liv_wkly_enrol_hdfs_path = config.get('LIVONGO','WEEKLY_ENROL_HDFS_PATH').replace('{$hdfs_env}','test')
    liv_wkly_bp_hdfs_path = config.get('LIVONGO','WEEKLY_BP_HDFS_PATH').replace('{$hdfs_env}','test')
    liv_wkly_bg_hdfs_path = config.get('LIVONGO','WEEKLY_BG_HDFS_PATH').replace('{$hdfs_env}','test')
    
    # OMADA related TEST changes
    omada_local_path = config.get('OMADA','LOCAL_PATH').replace('{$edge_env}','tst')
    omada_enroll_hdfs_path = config.get('OMADA','ENROLD_MEM_HDFS_PATH').replace('{$hdfs_env}','test')
    omada_clinical_hdfs_path = config.get('OMADA','CLINICAL_HDFS_PATH').replace('{$hdfs_env}','test')
    omada_nclinical_hdfs_path = config.get('OMADA','NCLINICAL_HDFS_PATH').replace('{$hdfs_env}','test')
    
     # HINGE HEALTH related TEST changes
    hinge_local_path = config.get('HINGEHEALTH','LOCAL_PATH').replace('{$edge_env}','tst')
    hinge_enroll_hdfs_path = config.get('HINGEHEALTH','ENROLL_HDFS_PATH').replace('{$hdfs_env}','test')
    hinge_clinical_hdfs_path = config.get('HINGEHEALTH','ENG_HDFS_PATH').replace('{$hdfs_env}','test')
    
    # OVIA related TEST changes
    ovia_local_path = config.get('OVIA','LOCAL_PATH').replace('{$edge_env}','tst')
    ovia_clinical_hdfs_path = config.get('OVIA','CLINICAL_HDFS_PATH').replace('{$hdfs_env}','test')
    ovia_enroll_hdfs_path = config.get('OVIA','ENROLL_HDFS_PATH').replace('{$hdfs_env}','test')
    
    # TIVITY related TEST changes
    tvty_local_path = config.get('TIVITY','LOCAL_PATH').replace('{$edge_env}','tst')
    tvty_hdfs_path = config.get('TIVITY','HDFS_PATH').replace('{$hdfs_env}','test')

# PROD changes
elif env.lower() == 'prod':
       
    # LIVONGO related PROD changes
    liv_local_path = config.get('LIVONGO','LOCAL_PATH').replace('{$edge_env}','prod')
    liv_wkly_enrol_hdfs_path = config.get('LIVONGO','WEEKLY_ENROL_HDFS_PATH').replace('{$hdfs_env}','prod')
    liv_wkly_bp_hdfs_path = config.get('LIVONGO','WEEKLY_BP_HDFS_PATH').replace('{$hdfs_env}','prod')
    liv_wkly_bg_hdfs_path = config.get('LIVONGO','WEEKLY_BG_HDFS_PATH').replace('{$hdfs_env}','prod')
    
     # OMADA related PROD changes
    omada_local_path = config.get('OMADA','LOCAL_PATH').replace('{$edge_env}','prod')
    omada_enroll_hdfs_path = config.get('OMADA','ENROLD_MEM_HDFS_PATH').replace('{$hdfs_env}','prod')
    omada_clinical_hdfs_path = config.get('OMADA','CLINICAL_HDFS_PATH').replace('{$hdfs_env}','prod')
    omada_nclinical_hdfs_path = config.get('OMADA','NCLINICAL_HDFS_PATH').replace('{$hdfs_env}','prod')
    
    # HINGE HEALTH related PROD changes
    hinge_local_path = config.get('HINGEHEALTH','LOCAL_PATH').replace('{$edge_env}','prod')
    hinge_enroll_hdfs_path = config.get('HINGEHEALTH','ENROLL_HDFS_PATH').replace('{$hdfs_env}','prod')
    hinge_clinical_hdfs_path = config.get('HINGEHEALTH','ENG_HDFS_PATH').replace('{$hdfs_env}','prod')
    
     # OVIA related PROD changes
    ovia_local_path = config.get('OVIA','LOCAL_PATH').replace('{$edge_env}','prod')
    ovia_clinical_hdfs_path = config.get('OVIA','CLINICAL_HDFS_PATH').replace('{$hdfs_env}','prod')
    ovia_enroll_hdfs_path = config.get('OVIA','ENROLL_HDFS_PATH').replace('{$hdfs_env}','prod')
    
    # TIVITY related PROD changes
    tvty_local_path = config.get('TIVITY','LOCAL_PATH').replace('{$edge_env}','prod')
    tvty_hdfs_path = config.get('TIVITY','HDFS_PATH').replace('{$hdfs_env}','prod')
    
# Printing OVIA values
print("Printing LIVONGO values")
print(liv_local_path)
print(liv_wkly_enrol_hdfs_path)
print(liv_wkly_bp_hdfs_path)
print(liv_wkly_bg_hdfs_path)
print('\n')
print("Printing OMADA values")
print(omada_local_path)
print(omada_enroll_hdfs_path)
print(omada_clinical_hdfs_path)
print(omada_nclinical_hdfs_path)
print('\n')
print("Printing HINGEHEALTH values")
print(hinge_local_path)
print(hinge_enroll_hdfs_path)
print(hinge_clinical_hdfs_path)
print('\n')
print("Printing OVIA values")
print(ovia_local_path)
print(ovia_clinical_hdfs_path)
print(ovia_enroll_hdfs_path)
print('\n')
print("Printing TIVITY values")
print(tvty_local_path)
print(tvty_hdfs_path)


# In[81]:


# File Pattern matching
# Testing on Windows directory
# Checking for LIVONGO files
'''
for file in glob.glob('C:\\Users\\ssrikeerti\\Desktop\\Notebooks\\'+config.get('LIVONGO','ENROLL_FILE_PATTERN')):
    #print(file)
    liv_enrol_file = os.path.basename(file)
    print(liv_enrol_file[26:-4])
    
     
for file in glob.glob('C:\\Users\\ssrikeerti\\Desktop\\Notebooks\\'+config.get('LIVONGO','BLOOD_PRESSURE_FILE_PATTERN')):
    #print(file)
    liv_bp_file = os.path.basename(file)
    print(liv_bp_file[18:-4])

for file in glob.glob('C:\\Users\\ssrikeerti\\Desktop\\Notebooks\\'+config.get('LIVONGO','BLOOD_GLUCOSE_FILE_PATTERN')):
    #print(file)
    liv_bg_file = os.path.basename(file)
    print(liv_bg_file)
    print(liv_bg_file[18:-4])
'''


# In[118]:


# File to pick for LIVONGO ENROLLMENT
# Picking file with latest timestamp
liv_enrol_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('LIVONGO','ENROLL_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
liv_enrol_file_dt = liv_enrol_file[26:-4].replace('_','')

# Command to move Weekly Enrollment file from Source to Destination
liv_enrol_cmd = 'hdfs dfs -put '+liv_local_path+liv_enrol_file+' '+liv_wkly_enrol_hdfs_path

#File to pick for LIVONGO BLOOD PRESSURE
# Picking file with latest timestamp
liv_bp_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('LIVONGO','BLOOD_PRESSURE_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
liv_bp_file_dt = liv_bp_file[18:-4].replace('_','')

# Command to move Blood Pressure file from Source to Destination
liv_bp_cmd = 'hdfs dfs -put '+liv_local_path+liv_bp_file+' '+liv_wkly_bp_hdfs_path

# File to pick for LIVONGO BLOOD GLUCOSE
# Picking file with latest timestamp
liv_bg_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('LIVONGO','BLOOD_GLUCOSE_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
liv_bg_file_dt = liv_bg_file[18:-4].replace('_','')

# Command to move Blood Glucose file from Source to Destination
liv_bg_cmd = 'hdfs dfs -put '+liv_local_path+liv_bg_file+' '+liv_wkly_bg_hdfs_path


# In[139]:


# File to pick for OMADA Enrollment
# Picking file with latest timestamp
omada_enrol_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('OMADA','ENROLL_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
#omada_enrol_file_dt = omada_enrol_file[23:-4].replace('_','')
omada_enrol_file_dt = omada_enrol_file[23:-4]

# Command to move Weekly Enrollment file from Source to Destination
omada_enrol_cmd = 'hdfs dfs -put '+omada_local_path+omada_enrol_file+' '+omada_enroll_hdfs_path

#File to pick for OMADA Clinical
# Picking file with latest timestamp
omada_clin_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('OMADA','CLINICAL_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
omada_clin_file_dt = omada_clin_file[14:-10].replace('_','')

# Command to move Clinical file from Source to Destination
omada_clin_cmd = 'hdfs dfs -put '+omada_local_path+omada_clin_file+' '+omada_clinical_hdfs_path

# File to pick for OMADA NON CLINICAL
# Picking file with latest timestamp
omada_nclin_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('OMADA','NCLINICAL_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
omada_nclin_file_dt = omada_nclin_file[16:-10].replace('_','')

# Command to move Non Clinical file from Source to Destination
omada_nclin_cmd = 'hdfs dfs -put '+omada_local_path+omada_nclin_file+' '+omada_nclinical_hdfs_path


# In[169]:


# File to pick for HINGEHEALTH
# Picking file with latest timestamp
# Enrollment file
hinge_enrol_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('HINGEHEALTH','ENROLL_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
hinge_enrol_file_dt = hinge_enrol_file[40:-12]

# Command to move Enrollment file from Source to Destination
hinge_enrol_cmd = 'hdfs dfs -put '+hinge_local_path+hinge_enrol_file+' '+hinge_enroll_hdfs_path

# File to pick for HINGEHEALTH
# Picking file with latest timestamp
# Clinical file
hinge_clin_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('HINGEHEALTH','CLINICAL_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
hinge_clin_file_dt = hinge_clin_file[48:-12]

# Command to move clinical file from Source to Destination
hinge_clin_cmd = 'hdfs dfs -put '+hinge_local_path+hinge_clin_file+' '+hinge_clinical_hdfs_path


# In[174]:


# File to pick for OVIA
# Picking file for latest timestamp
# Clinical file
ovia_enrol_file = os.path.basename(max(glob.glob(config.get('TEST','WINDOWS_PATH')+config.get('OVIA','ENROLL_FILE_PATTERN')), 
          key=os.path.getmtime))

# Capturing date which will be used for Partitioning
ovia_enrol_file_dt = ovia_enrol_file[38:-12]

# Command to move Enrollment file from Source to Destination
ovia_enrol_cmd = 'hdfs dfs -put '+ovia_local_path+ovia_enrol_file+' '+ovia_clinical_hdfs_path


# In[175]:


print(ovia_enrol_file)
print(ovia_enrol_file_dt)
print(ovia_enrol_cmd)


# In[ ]:


# File to pick for TIVITY


# In[107]:


# Creating list of lists source wise
# which has partition information
liv_data = [[liv_enrol_file,liv_enrol_file_dt,liv_enrol_cmd],
            [liv_bp_file,liv_bp_file_dt,liv_bp_cmd],
            [liv_bg_file,liv_bg_file_dt,liv_bg_cmd]]


# In[108]:


# Printing captured values
print(liv_enrol_file+" --- "+liv_enrol_file_dt+"---\n"+liv_enrol_cmd)
print(liv_bp_file+" --- "+liv_bp_file_dt+"---\n"+liv_bp_cmd)
print(liv_bg_file+" --- "+liv_bg_file_dt+'---\n'+liv_bg_cmd)


# In[109]:


with open(config.get('TEST','WINDOWS_PATH')+wbm_partition_info.csv','w',newline='') as f:
    #writer = csv.writer('wbm_partition_info.csv',delimiter=',')
    writer = csv.writer(f,delimiter=',')
    writer.writerows(liv_data)

